
function [O]=mps_snesim_enesim_par(filename);
if nargin==0
    filename='mps_snesim_tree.txt';
end


O.filename_parameter=filename;

fid=fopen(O.filename_parameter,'r');

% number of realizations
l=line_strip_char(fgetl(fid),'#');
O.n_real=str2num(l);

% random seed
l=line_strip_char(fgetl(fid),'#');
O.rseed=str2num(l);

% # max number of conditional counts for setting up cPDF
l=line_strip_char(fgetl(fid),'#');
O.n_max_cpdf_count=str2num(l);

% # max number of conditional data
l=line_strip_char(fgetl(fid),'#');
O.n_cond=str2num(l);

% # max number of neighbors
l=line_strip_char(fgetl(fid),'#');
O.n_max_ite=str2num(l);


% SIMULATION GRID SIZE
for i=1:3;
  l=line_strip_char(fgetl(fid),'#');
  O.simulation_grid_size(i)=str2num(l);
end

% WORLD/ORIGIN SIZE
for i=1:3;
  l=line_strip_char(fgetl(fid),'#');
  O.origin(i)=str2num(l);
end

% GRID CELL SIZE
for i=1:3;
  l=line_strip_char(fgetl(fid),'#');
  O.grid_cell_size(i)=str2num(l);
end


% training image
l=line_strip_char(fgetl(fid),'#');
O.ti_filename=strip_space(l);

l=line_strip_char(fgetl(fid),'#');
O.output_folder=strip_space(l);

l=line_strip_char(fgetl(fid),'#');
O.shuffle_simulation_grid=str2num(l);

% l=line_strip_char(fgetl(fid),'#');
% O.entropyfactor_simulation_grid=str2num(l);
O.entropyfactor_simulation_grid=4;

l=line_strip_char(fgetl(fid),'#');
O.shuffle_ti_grid=str2num(l);

% HARD DATA
l=line_strip_char(fgetl(fid),'#');
O.hard_data_filename=strip_space(l);

l=line_strip_char(fgetl(fid),'#');
O.hard_data_search_radius=str2num(l);

% SOFT DATA

l=line_strip_char(fgetl(fid),'#');
O.soft_data_categories=strip_space(l);

l=line_strip_char(fgetl(fid),'#');
O.soft_data_filename=strip_space(l);



l=line_strip_char(fgetl(fid),'#');
O.n_threads=str2num(l);

l=line_strip_char(fgetl(fid),'#');
O.debug=str2num(l);

% set x,y, and z parameters
O.x=[0:(O.simulation_grid_size(1)-1)].*O.grid_cell_size(1)+O.origin(1);
O.y=[0:(O.simulation_grid_size(2)-1)].*O.grid_cell_size(2)+O.origin(2);
O.z=[0:(O.simulation_grid_size(3)-1)].*O.grid_cell_size(3)+O.origin(3);


fclose(fid);



function l=line_strip_char(l,char)
i=strfind(l,char);
l=l(i+1:end);


